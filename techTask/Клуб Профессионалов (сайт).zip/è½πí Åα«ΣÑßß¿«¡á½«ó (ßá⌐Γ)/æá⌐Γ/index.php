<?php
include_once 'handler.php'; // проверяем авторизирован ли пользователь

if($user) {
// выводим информацию для пользователя
header ('Location: lk.php');
exit();
} else {
// выводим информацию для гостя
header ('Location: index.html');
exit();
}
?>