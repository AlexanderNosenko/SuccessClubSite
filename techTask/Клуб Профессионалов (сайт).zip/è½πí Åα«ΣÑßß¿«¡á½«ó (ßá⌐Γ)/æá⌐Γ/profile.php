<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Мой профиль | Клуб Профессионалов</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">

</head>

<body class="fixed-sidebar no-skin-config">

    <div id="wrapper">


    <nav class="navbar-default navbar-static-side" role="navigation" style="position: fixed">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="img/profile_small.jpg" />
                             </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="mailbox.html#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">
                            <?php
                                include_once 'handler.php'; // проверяем авторизирован ли пользователь
                                    if($user) {
                                        $search_name = mysql_query("SELECT `name` FROM `users` WHERE `username` = '".$user['username']."'");
                                        $name = (mysql_num_rows($search_name) == 1) ? mysql_fetch_array($search_name) : 0;

                                        $search_surname = mysql_query("SELECT `surname` FROM `users` WHERE `username` = '".$user['username']."'");
                                        $surname = (mysql_num_rows($search_surname) == 1) ? mysql_fetch_array($search_surname) : 0;
                                        echo $name['name'], '&nbsp;', $surname['surname'];                                    
                                        } else {
                                        // выводим информацию для гостя
                                        header ('Location: index.html');
                                        exit();
                                        }
                            ?>
                            </strong>
                             </span>
							<p>Логин:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['username'];
                            ?></b><br>
							Ваш id:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['user_id'];
                            ?></b></p>
                    </a>
                </div>
                <div class="logo-element">
                    КП
                </div>
            </li>
            <li>
                <a href="lk.php"><i class="fa fa-th-large"></i> <span class="nav-label">Главная</span></a>
            </li>
            <li>
                <a href="profile.php"><i class="fa fa-diamond"></i> <span class="nav-label">Профиль</span></a>
            </li>
            <li>
                <a href="comanda.php"><i class="fa fa-users"></i> <span class="nav-label">Команда</span></a>
            </li>
            <!--
            <li class="active">
                <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">Сообщения</span><span class="label label-warning pull-right">16</span></a>
            </li>
            -->
            <li>
                <a href="404.php"><i class="fa fa-envelope"></i> <span class="nav-label">Сообщения</span><span class="label label-warning pull-right">0</span></a>
            </li>
            <li>
                <a href="money.php"><i class="fa fa-money"></i> <span class="nav-label">Быстрые деньги</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-bank"></i> <span class="nav-label">Бизнес</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="404.php">Мои бизнесы</a></li>
                    <li><a href="404.php">Выбор бизнеса</a></li>
                </ul>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-edit"></i> <span class="nav-label">Инструменты</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="404.php">Мои инструменты</a></li>
                    <li><a href="404.php">Выбор инструментов</a></li>
                </ul>
            </li>

            <li>
                <a href="404.php"><i class="fa fa-line-chart"></i> <span class="nav-label">Финансы</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-bullhorn"></i> <span class="nav-label">Мероприятия</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-book"></i> <span class="nav-label">Вопрос / Ответ</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-edit"></i> <span class="nav-label">Другие сервисы</span><span class="fa arrow"></span></a>
            </li>
            <li>
                <a href="cooperation.php"><i class="fa fa-th"></i> <span class="nav-label">Сотрудничество</span></a>
            </li>
        </ul>

    </div>
</nav>
        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0;">
    <div class="navbar-header">
        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary" href="#" title="Скрыть меню"><i class="fa fa-bars"></i> </a>
        <form role="search" class="navbar-form-custom" action="search_results.html">
            <div class="form-group">
                <input type="text" placeholder="Поиск" class="form-control" name="top-search" id="top-search">
            </div>
        </form>
    </div>
    <ul class="nav navbar-top-links navbar-right">
        <li class="dropdown">
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="mailbox.html#">
                <i class="fa fa-envelope"></i>  <span class="label label-warning">0</span>
            </a>
            <ul class="dropdown-menu dropdown-messages">
                <li>
                    <div class="text-center link-block">
                        <a href="#">
                            <i class="fa fa-envelope"></i> <strong>Прочесть сообщения</strong>
                        </a>
                    </div>
                </li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                <i class="fa fa-bell"></i>  <span class="label label-primary">0</span>
            </a>
            <ul class="dropdown-menu dropdown-alerts">
                
                    <div class="text-center link-block">
                        <a href="#">
                            <strong>Прочесть увдеомеления</strong>
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                </li>
            </ul>
        </li>


        <li><form action="http://improf.club/exit.php" method="post">
                <button type="submit" class="btn btn-primary block full-width m-b"><i class="fa fa-power-off"> Выход</i></button>

            </form>
        </li>
    </ul>

</nav>        
<div class="wrapper wrapper-content animated fadeInRight">


            <div class="row m-b-lg m-t-lg">
                <div class="col-md-6">
                    <div class="profile-image">
                        <img src="img/a4.jpg" class="img-circle circle-border m-b-md" alt="profile">
                    </div>
                    <div class="profile-info">
                        <div class="">
                            <p class="small font-bold text-left">
                                <span><i class="fa fa-circle text-navy"></i> Online</span>
                            </p>
                            <div>
                                <h2 class="no-margins">
                            <?php
                                include_once 'handler.php'; // проверяем авторизирован ли пользователь
                                    if($user) {
                                        $search_name = mysql_query("SELECT `name` FROM `users` WHERE `username` = '".$user['username']."'");
                                        $name = (mysql_num_rows($search_name) == 1) ? mysql_fetch_array($search_name) : 0;

                                        $search_surname = mysql_query("SELECT `surname` FROM `users` WHERE `username` = '".$user['username']."'");
                                        $surname = (mysql_num_rows($search_surname) == 1) ? mysql_fetch_array($search_surname) : 0;
                                        echo $name['name'], '&nbsp;', $surname['surname'];                                    
                                        } else {
                                        // выводим информацию для гостя
                                        header ('Location: index.html');
                                        exit();
                                        }
                            ?>

                                <br><small> Логин:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['username'];
                            ?></b></small>
							<br><small> E-mail:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['mail'];
                            ?></b></small>
							<br><small> Ваш id:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['user_id'];
                            ?></b></small>
							<br>
							<small>Cсылка для приглашения партнеров: <?php
								include_once 'handler.php'; // проверяем авторизирован ли пользователь
									if($user) {
										$search_id = mysql_query("SELECT `user_id` FROM `users` WHERE `username` = '".$user['username']."'");
										$id = (mysql_num_rows($search_id) == 1) ? mysql_fetch_array($search_id) : 0;
                                        echo '<div style="font-size: 17px; color: #0f6b58;"><b>http://improf.club/register_p.php?p='.$id['user_id'].'</b></div>';
										//echo '<input type="text" class="form-control" disabled="" placeholder="http://improf.club/register_p.php?p='.$id['user_id'].'">';
                                        //echo '<span class="input-group-btn">
                                        //        <button type="button" class="btn btn-primary">Копировать</button>
                                        //      </span>';
                                    
										} else {
										// выводим информацию для гостя
										header ('Location: index.html');
										exit();
										}
							?></small>
							</h2> 
                            </div>
                        </div>
                    </div>
                </div>
             <!--   <div class="col-md-3">
                    <table class="table small m-b-xs">
                        <tbody>
                        <tr>
                            <td>
                                <strong>142</strong> Текст
                            </td>
                            <td>
                                <strong>22</strong> Текст
                            </td>

                        </tr>
                        <tr>
                            <td>
                                <strong>61</strong> Текст
                            </td>
                            <td>
                                <strong>54</strong> Текст
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>154</strong> Текст
                            </td>
                            <td>
                                <strong>32</strong> Текст
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-3">
                    <small>Прибыли за месяц</small>
                    <h2 class="no-margins">1200 $</h2>
                    <div id="sparkline1"></div>
                </div>-->
            </div>
          <!--  <div class="row">

                <div class="col-lg-5">
                    <div class="ibox">
                        <div class="ibox-content">
                            <h3>О себе</h3>
                            <p style="font-size: 13px">
                                Человек — живое разумное общественное существо, субъект общественно-исторической деятельности и культуры.
                                <br/>
                                <br/>
                                Человек — живое разумное общественное существо, субъект общественно-исторической деятельности и культуры.
                            </p>
                        </div>
                    </div>
                    <div class="ibox">
                        <div class="ibox-content">
                            <h3>Команда</h3>

                            <div class="user-friends">
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a3.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a1.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a2.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a4.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a5.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a6.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a7.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a8.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a2.jpg"></a>
                                <a href="profile_2.html"><img alt="image" class="img-circle" src="img/a1.jpg"></a>
                            </div><br>
                            <button type="button" class="btn btn-primary btn-sm btn-block"> Посмотреть
                            </button>
                        </div>
                    </div>

                </div>

                <div class="col-lg-3">
                    <div class="ibox">
                        <div class="ibox-content">
                            <ul class="list-group clear-list">
                                <li class="list-group-item fist-item">
                                    <i class="fa fa-map-marker"></i> <span class="nav-label">Украина, Одесса</span>
                                </li>
                                <li class="list-group-item">
                                    <i class="fa fa-at"></i> <span class="nav-label">ivan@mail.ru</span>
                                </li>
                                <li class="list-group-item">

                                    <i class="fa fa-phone"></i> <span class="nav-label">+38098-48-76-048</span>
                                </li>
                                <li class="list-group-item">

                                    <i class="fa fa-skype"></i> <span class="nav-label">ivan234</span>
                                </li>
                                <li class="list-group-item">
                                    <i class="fa fa-vk"></i>&nbsp;
                                    <i class="fa fa-facebook"></i>&nbsp;
                                    <i class="fa fa-google-plus"></i>&nbsp;
                                    <i class="fa fa-instagram"></i>&nbsp;
                                    <i class="fa fa-linkedin"></i>&nbsp;
                                    <i class="fa fa-twitter"></i>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 m-b-lg">
                    <div class="ibox">
                        <div class="ibox-content">
                            <h3>Сообщение</h3>

                            <p class="small">
                                Отправить для Имя Фамилия
                            </p>

                            <div class="form-group">
                                <label>Тема</label>
                                <input type="email" class="form-control" placeholder="Тема">
                            </div>
                            <div class="form-group">
                                <label>Сообщение</label>
                                <textarea class="form-control" placeholder="Текс сообщения" rows="3"></textarea>
                            </div>
                            <button class="btn btn-primary btn-block">Отправить</button>

                        </div>
                    </div>

                </div>
            </div>-->

        </div>
    <div class="footer">
        <div class="pull-right">
        
        </div>
    <div>
        <strong>Клуб Профессионалов</strong> Копирование материалов ЗАПРЕЩЕНО!  &copy; 2016
    </div>


        </div>
        </div>
    </div>



    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Sparkline -->
    <script src="js/plugins/sparkline/jquery.sparkline.min.js"></script>

    <script>
        $(document).ready(function() {


            $("#sparkline1").sparkline([34, 43, 43, 35, 44, 32, 44, 48], {
                type: 'line',
                width: '100%',
                height: '50',
                lineColor: '#1ab394',
                fillColor: "transparent"
            });


        });
    </script>

	<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '7VymgCnRUS';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
</body>

</html>
