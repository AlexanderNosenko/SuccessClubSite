<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta property="og:image" content="img/landing/logo12.png" />
	<meta name="description" content="Клуб Профессионалов - это платформа, объединяющая людей, с целью заработка денег через Интернет.">
	
    <title>Быстрые деньги | Клуб Профессионалов</title>
	
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



</head>

<body class="fixed-sidebar no-skin-config">

<div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation" style="position: fixed">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="img/profile_small.jpg" />
                             </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="mailbox.html#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">
                            <?php
                                include_once 'handler.php'; // проверяем авторизирован ли пользователь
                                    if($user) {
                                        $search_name = mysql_query("SELECT `name` FROM `users` WHERE `username` = '".$user['username']."'");
                                        $name = (mysql_num_rows($search_name) == 1) ? mysql_fetch_array($search_name) : 0;

                                        $search_surname = mysql_query("SELECT `surname` FROM `users` WHERE `username` = '".$user['username']."'");
                                        $surname = (mysql_num_rows($search_surname) == 1) ? mysql_fetch_array($search_surname) : 0;
                                        echo $name['name'], '&nbsp;', $surname['surname'];                                    
                                        } else {
                                        // выводим информацию для гостя
                                        header ('Location: index.html');
                                        exit();
                                        }
                            ?>
                            </strong>
                             </span>
							 <p>Логин:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['username'];
                            ?></b><br>
							Ваш id:                         
                                <b><?php

                                include_once 'handler.php'; // проверяем авторизирован ли пользователь

                            echo $user['user_id'];
                            ?></b></p>
                    </a>
                </div>
                <div class="logo-element">
                    КП
                </div>
            </li>
            <li>
                <a href="lk.php"><i class="fa fa-th-large"></i> <span class="nav-label">Главная</span></a>
            </li>
            <li>
                <a href="profile.php"><i class="fa fa-diamond"></i> <span class="nav-label">Профиль</span></a>
            </li>
            <li>
                <a href="comanda.php"><i class="fa fa-users"></i> <span class="nav-label">Команда</span></a>
            </li>
            <!--
            <li class="active">
                <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">Сообщения</span><span class="label label-warning pull-right">16</span></a>
            </li>
            -->
            <li>
                <a href="404.php"><i class="fa fa-envelope"></i> <span class="nav-label">Сообщения</span><span class="label label-warning pull-right">0</span></a>
            </li>
			<li>
                <a href="money.php"><i class="fa fa-money"></i> <span class="nav-label">Быстрые деньги</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-bank"></i> <span class="nav-label">Бизнес</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="404.php">Мои бизнесы</a></li>
                    <li><a href="404.php">Выбор бизнеса</a></li>
                </ul>
            </li>
			<li>
                <a href="404.php"><i class="fa fa-edit"></i> <span class="nav-label">Инструменты</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="404.php">Мои инструменты</a></li>
                    <li><a href="404.php">Выбор инструментов</a></li>
                </ul>
            </li>

            <li>
                <a href="404.php"><i class="fa fa-line-chart"></i> <span class="nav-label">Финансы</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-bullhorn"></i> <span class="nav-label">Мероприятия</span></a>
            </li>
			<li>
                <a href="404.php"><i class="fa fa-book"></i> <span class="nav-label">Вопрос / Ответ</span></a>
            </li>
            <li>
                <a href="404.php"><i class="fa fa-edit"></i> <span class="nav-label">Другие сервисы</span><span class="fa arrow"></span></a>
			</li>
            <li>
                <a href="404.php"><i class="fa fa-th"></i> <span class="nav-label">Сотрудничество</span></a>
            </li>
        </ul>

    </div>
</nav>


    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0;">
    <div class="navbar-header">
        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary" href="#" title="Скрыть меню"><i class="fa fa-bars"></i> </a>
        <form role="search" class="navbar-form-custom" action="search_results.html">
            <div class="form-group">
                <input type="text" placeholder="Поиск" class="form-control" name="top-search" id="top-search">
            </div>
        </form>
    </div>
    <ul class="nav navbar-top-links navbar-right">
        <li class="dropdown">
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="mailbox.html#">
                <i class="fa fa-envelope"></i>  <span class="label label-warning">0</span>
            </a>
            <ul class="dropdown-menu dropdown-messages">
                <li>
                    <div class="text-center link-block">
                        <a href="#">
                            <i class="fa fa-envelope"></i> <strong>Прочесть сообщения</strong>
                        </a>
                    </div>
                </li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                <i class="fa fa-bell"></i>  <span class="label label-primary">0</span>
            </a>
            <ul class="dropdown-menu dropdown-alerts">
                
                    <div class="text-center link-block">
                        <a href="#">
                            <strong>Прочесть увдеомеления</strong>
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                </li>
            </ul>
        </li>


        <li><form action="http://improf.club/exit.php" method="post">
                <button type="submit" class="btn btn-primary block full-width m-b"><i class="fa fa-power-off"> Выход</i></button>

			</form>
        </li>
    </ul>

</nav>
        <div class="wrapper wrapper-content animated fadeInRight">
			<div class="col-md-7">
					<div class="ibox">
                        <div class="ibox-title text-center">
                            <h2>Уровень 1</h2>
                        </div>
                        <div class="ibox-content">
                            <div class="row">
                            <div class="col-md-6">
                                <p style="font-size: 16px;"><i class="fa fa-users" style="color: #1AB394"></i>&nbsp;14</p>
                                <p style="font-size: 16px;">Вход: $2</p>
                            </div>
                            <div class="col-md-6 text-center">
                                <p style="font-size: 16px;">Круг: $14</p>
                            </div>
                            </div>
                        </div>
					</div>
		<p style="font-size: 16px; color: #8B0000;">Направление запущено в ручном режиме, автоматизированная система будет готова после 5 июня!</p>
		<p style="font-size: 16px;">
		Для перехода на Уровень 1 необходимо:<br>
		- перевести <b>$2</b> на <b>U52137923986425</b> (NixMoney) или <b>U757631680131</b> (AdvCash) <br>
		- заполнить форму справа<br>
		После заполнения формы на ваш E-mail будет отправлено письмо, не забудьте проверить почту!<br>
		Заявка обрабатывается оператором до 3 часов!
		</p>
		</div>
			<div class="col-md-5">
		<style>
#feedback-form {
  max-width: 500px;
  background: #f3f3f4;
  font-size: 17px;
}
#feedback-form [required] {
  width: 100%;
  box-sizing: border-box;
  margin: 2px 0 2% 0;
  padding: 2%;
  border: 1px solid rgba(0,0,0,.1);
  border-radius: 3px;
  box-shadow: 0 1px 2px -1px rgba(0,0,0,.2) inset, 0 0 transparent;
}
#feedback-form [required]:hover {
  border-color: #7eb4ea;
  box-shadow: 0 1px 2px -1px rgba(0,0,0,.2) inset, 0 0 transparent;
}
#feedback-form [required]:focus {
  outline: none;
  border-color: #7eb4ea;
  box-shadow: 0 1px 2px -1px rgba(0,0,0,.2) inset, 0 0 4px rgba(35,146,243,.5);
  transition: .2s linear;
}
#feedback-form [type="submit"] {
  padding: 5px 5px;
  border: none;
  border-radius: 3px;
  box-shadow: 0 0 0 1px rgba(0,0,0,.2) inset;
  background: #1ab394;
  color: #fff;
}
#feedback-form [type="submit"]:hover {
  background: #5c90c2;
}
#feedback-form [type="submit"]:focus {
  box-shadow: 0 1px 1px #fff, inset 0 1px 2px rgba(0,0,0,.8), inset 0 -1px 0 rgba(0,0,0,.05);
}
</style>

<?
if (isset ($_POST['messageFF'])) {
  mail ("improfclub@gmail.com",
        "Новая заявка на Быстрые Деньги ".$_SERVER['HTTP_REFERER'],
        "Имя: ".$_POST['nameFF']."\nEmail: ".$_POST['contactFF']."\nНомер транзакции: ".$_POST['messageFF']."\nПлатежная система: ".$_POST['pc']);
  echo ('<p style="color: green">Заявка успешно отправлена, ожидайте ответ на E-mail</p>');
}
?>

<form method="POST" id="feedback-form" name="f" method="get" action="<?=$_SERVER['PHP_SELF']?>">
<input type="text" name="nameFF" required placeholder="Имя" x-autocompletetype="name">
<input type="email" name="contactFF" required placeholder="E-mail (указанный при регистрации)" x-autocompletetype="email">
<input name="messageFF" required placeholder="Номер транзакции перевода">
<div><label> <input type="radio" value="AdvCash" name="pc"> <i></i>AdvCash</label></div>
<div><label> <input type="radio" value="NixMoney" name="pc"> <i></i>NixMoney</label></div>
<p class="text-center">Все поля необходимо заполнить!</p>
<div class="text-center"><input type="submit" value="Отправить"></div>
</form>
		
	</div>
		
    </div>
		
	<div class="footer">
		<div class="pull-right">
        
		</div>
    <div>
        <strong>Клуб Профессионалов</strong> Копирование материалов ЗАПРЕЩЕНО!  &copy; 2016
    </div>

    </div>
</div>



<!-- Mainly scripts -->
<script src="js/jquery-2.1.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>

<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '7VymgCnRUS';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

</body>

</html>
