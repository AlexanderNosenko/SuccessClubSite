<!DOCTYPE html>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Личный кабинет | Клуб Профессионалов</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



</head>

<body class="fixed-sidebar no-skin-config">

<div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation" style="position: fixed">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="img/profile_small.jpg" />
                             </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="mailbox.html#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Имя Фамилия</strong>
                             </span>
                                <span class="text-muted text-xs block" title="Звание в Маркетинг Плане КП">Звание</span> </span> </a>
                </div>
                <div class="logo-element">
                    КП
                </div>
            </li>
            <li>
                <a href="panel.php"><i class="fa fa-th-large"></i> <span class="nav-label">Главная</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-diamond"></i> <span class="nav-label">Профиль</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Команда</span></a>
            </li>
            <!--
            <li class="active">
                <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">Сообщения</span><span class="label label-warning pull-right">16</span></a>
            </li>
            -->
            <li>
                <a href="#"><i class="fa fa-envelope"></i> <span class="nav-label">Сообщения</span><span class="label label-warning pull-right">0</span></a>
            </li>
			<li>
                <a href="#"><i class="fa fa-money"></i> <span class="nav-label">Быстрые деньги</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-bank"></i> <span class="nav-label">Бизнес</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="#">Мои бизнесы</a></li>
                    <li><a href="#">Выбор бизнеса</a></li>
                </ul>
            </li>
			<li>
                <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Инструменты</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="#">Мои инструменты</a></li>
                    <li><a href="#">Выбор инструментов</a></li>
                </ul>
            </li>

            <li>
                <a href="#"><i class="fa fa-line-chart"></i> <span class="nav-label">Финансы</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-line-chart"></i> <span class="nav-label">Мероприятия</span></a>
            </li>
			<li>
                <a href="#"><i class="fa fa-book"></i> <span class="nav-label">Вопрос / Ответ</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Другие сервисы</span><span class="fa arrow"></span></a>
			</li>
            <li>
                <a href="#"><i class="fa fa-th"></i> <span class="nav-label">Сотрудничество</span></a>
            </li>
        </ul>

    </div>
</nav>


    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0;">
    <div class="navbar-header">
        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary" href="#" title="Скрыть меню"><i class="fa fa-bars"></i> </a>
        <form role="search" class="navbar-form-custom" action="search_results.html">
            <div class="form-group">
                <input type="text" placeholder="Поиск" class="form-control" name="top-search" id="top-search">
            </div>
        </form>
    </div>
    <ul class="nav navbar-top-links navbar-right">
        <li class="dropdown">
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="mailbox.html#">
                <i class="fa fa-envelope"></i>  <span class="label label-warning">0</span>
            </a>
            <ul class="dropdown-menu dropdown-messages">
                <li>
                    <div class="text-center link-block">
                        <a href="#">
                            <i class="fa fa-envelope"></i> <strong>Прочесть сообщения</strong>
                        </a>
                    </div>
                </li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                <i class="fa fa-bell"></i>  <span class="label label-primary">0</span>
            </a>
            <ul class="dropdown-menu dropdown-alerts">
                
                    <div class="text-center link-block">
                        <a href="#">
                            <strong>Прочесть увдеомеления</strong>
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                </li>
            </ul>
        </li>


        <li><form action="http://improf.club/exit.php" method="post">
                <button type="submit" class="btn btn-primary block full-width m-b">Выход</button>

			</form>
        </li>
    </ul>

</nav>
        <div class="wrapper wrapper-content animated fadeInRight">


            <div class="row">
                <div class="col-md-6">
                    <div class="ibox ">
                        <div class="ibox-title text-center">
                            <h2>Баланс</h2>
                        </div>
                        <div class="ibox-content col-md-12">
                            <div class="col-md-7 text-center">
                                <button type="button" class="btn btn-primary btn-sm btn-block" style="font-size: 16px" title="Пополнить свой баланс с помощью платежных систем">Пополнить баланс</button>
                                <button type="button" class="btn btn-primary btn-sm btn-block" style="font-size: 16px" title="Получить денежки на свой кошелекы">Вывести средства</button>
                            </div>
							<div class="col-md-5">
                                <p style="font-size: 22px; color: #85bb65" title="Доступный баланс"><i class="fa fa-usd"></i>&nbsp; 0.00</p>
                                <p style="font-size: 20px; color: #B22222" title="Бонусы"><i class="fa fa-database"></i>&nbsp; 0.00</p>
                            </div>
                        </div>
                    </div>
                </div>
				 <div class="col-md-6">
                    <div class="ibox">
                        <div class="ibox-title text-center">
                            <h2>Партнерская ссылка</h2>
                        </div>
                        <div class="ibox-content text-center">
						
                            <div class="input-group text-center">
							<?php
								include_once 'handler.php'; // проверяем авторизирован ли пользователь
									if($user) {
										$search_id = mysql_query("SELECT `user_id` FROM `users` WHERE `username` = '".$user['username']."'");
										$id = (mysql_num_rows($search_id) == 1) ? mysql_fetch_array($search_id) : 0;
										echo '<h4>http://improf.club/register_ref.php?p='.$id['user_id'].'</h4>';
										} else {
										// выводим информацию для гостя
										header ('Location: index.html');
										exit();
										}
							?>
							
							<!--<input type="text" class="form-control" disabled="" placeholder="http://improf.club/p/123423"> -->
							<span class="input-group-btn">
                            <!--<button type="button" class="btn btn-primary">Копировать</button> -->
							</span>
                            </div>
                            <br>
                            <div style="font-size: 14px">
                                
                                    <i class="fa fa-eye" title="Количество переходов по ссылке"> Просмотров: ...</i>&nbsp; 	
                                    <i class="fa fa-users" title="Количество зарегистрировавшихся партнеров по ссылке"> Партнеров: ...</i>&nbsp; 
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">

                <div class="col-lg-7">

                    <div class="ibox">
                        <div class="ibox-title text-center">
                            <h2>С чего начать?</h2>
                        </div>
                        <div class="ibox-content text-center">
                            <figure>
                                <iframe width="100%" height="320" src="https://www.youtube.com/embed/INOLQwoiXcY" frameborder="0" allowfullscreen></iframe>
                            </figure>
                        </div>
                    </div>

                </div>
                <div class="col-lg-5 text-left">
                    <div style="margin-top: 100px;">
                            <a href="#">
                                <button type="button" class="btn lazur-bg m-r-sm btn-block" style="font-size: 25px; text-align:left" title="Выбрать направление бизнеса"><i
                                        class="fa fa-briefcase"></i>&nbsp;Шаг №1 Бизнес</button>
                            </a>
                            <span style='padding-left:10px;'> </span>

                            <a href="#">
                                <button type="button" class="btn red-bg m-r-sm btn-block" style="font-size: 25px; text-align:left" title="Активировать инструменты"><i
                                        class="fa fa-cogs"></i>&nbsp;Шаг №2 Инструменты</button>
                            </a>
                            <span style='padding-left:10px;'> </span>

                            <a href="#">
                                <button type="button" class="btn yellow-bg m-r-sm btn-block" style="font-size: 25px; text-align:left" title="Пройти обучение"><i
                                        class="fa fa-graduation-cap"></i>&nbsp;Шаг №3 Обучение</button>
                            </a>
                    </div>

                </div>


            </div>

        </div>

	<div class="footer">
		<div class="pull-right">
        
		</div>
    <div>
        <strong>Клуб Профессионалов</strong> Копирование материалов ЗАПРЕЩЕНО!  &copy; 2016
    </div>

    </div>
</div>



<!-- Mainly scripts -->
<script src="js/jquery-2.1.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>

</body>

</html>
