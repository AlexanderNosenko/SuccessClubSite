<?php

mysql_connect('localhost', 'improfcl_user', 'improfcl_pass') or die('Ошибка соеденения с MySQL!');
mysql_select_db('improfcl_improf') or die ('Ошибка соеденения с базой данных MySQL!');
mysql_query('SET NAMES `utf8`'); // выставляем кодировку базы данных

?>