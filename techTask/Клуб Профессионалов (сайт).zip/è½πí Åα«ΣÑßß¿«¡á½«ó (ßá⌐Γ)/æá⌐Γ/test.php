<?php
include_once 'handler.php'; // проверяем авторизирован ли пользователь
$ic = 'http';
if($user) {
$search_id = mysql_query("SELECT `user_id` FROM `users_profiles` WHERE `username` = '".$user['username']."'");
$id = (mysql_num_rows($search_id) == 1) ? mysql_fetch_array($search_id) : 0;
echo $id['user_id'];
} else {
// выводим информацию для гостя
header ('Location: index.html');
exit();
}
?>