<?php
header( "Content-Encoding: utf-8" );

$pu = [' '];

$name = $_POST['name'];
$number = $_POST['number'];
$mail = $_POST['mail'];

$pc = $_POST['pc'];

$d = $_POST['d'];
$e = $_POST['e'];
$f = $_POST['f'];
$g = $_POST['g'];
$h = $_POST['h'];
$other1 = $_POST['other1'];

$rus = $_POST['rus'];
$ukr = $_POST['ukr'];
$eng = $_POST['eng'];
$other2 = $_POST['other2'];

$i = $_POST['i'];
$j = $_POST['j'];
$k = $_POST['k'];
$other3 = $_POST['other3'];

$other4 = $_POST['other4'];

$l = $_POST['l'];
$m = $_POST['m'];
$n = $_POST['n'];
$other5 = $_POST['other5'];

$other6 = $_POST['other6'];

$o = $_POST['o'];
$p = $_POST['p'];
$q = $_POST['q'];
$other7 = $_POST['other7'];

$other8 = $_POST['other8'];

$file=fopen("$name.txt",'a+');
fputs($file,$name.PHP_EOL);
fputs($file,$number.PHP_EOL);
fputs($file,$mail.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$pc.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$d.PHP_EOL);
fputs($file,$e.PHP_EOL);
fputs($file,$f.PHP_EOL);
fputs($file,$g.PHP_EOL);
fputs($file,$h.PHP_EOL);
fputs($file,$other1.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$rus.PHP_EOL);
fputs($file,$ukr.PHP_EOL);
fputs($file,$eng.PHP_EOL);
fputs($file,$other2.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$i.PHP_EOL);
fputs($file,$j.PHP_EOL);
fputs($file,$k.PHP_EOL);
fputs($file,$other3.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$other4.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$l.PHP_EOL);
fputs($file,$m.PHP_EOL);
fputs($file,$n.PHP_EOL);
fputs($file,$other5.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$other6.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$o.PHP_EOL);
fputs($file,$p.PHP_EOL);
fputs($file,$q.PHP_EOL);
fputs($file,$other7.PHP_EOL);
fputs($file,$pu.PHP_EOL);

fputs($file,$other8.PHP_EOL);

fclose($file);

header ('Location: lk.php');
exit();
?>