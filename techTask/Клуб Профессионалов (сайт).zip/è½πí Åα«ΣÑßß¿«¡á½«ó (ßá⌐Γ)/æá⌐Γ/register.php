<?php
include_once 'handler.php'; // проверяем авторизирован ли пользователь

// если да, перенаправляем его на главную страницу
if($user) {
header ('Location: index.php');
exit();
}

if (!empty($_POST['login']) AND !empty($_POST['password']) AND !empty($_POST['mail']) AND !empty($_POST['name']) AND !empty($_POST['surname']))
{
// фильтрируем логин и пароль
$login = mysql_real_escape_string(htmlspecialchars($_POST['login']));
$password = mysql_real_escape_string(htmlspecialchars($_POST['password']));
$mail = mysql_real_escape_string(htmlspecialchars($_POST['mail']));
$name = mysql_real_escape_string(htmlspecialchars($_POST['name']));
$surname = mysql_real_escape_string(htmlspecialchars($_POST['surname']));


// проверяем есть ли логин в нашей базе данных
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE (`username` = '".$login."') or (`mail` = '".$mail."');"), 0) != 0)
{
header ('Location: register.html');
exit();
}

// заносим данные в таблицу, обратите внимание - пароль кодируем в md5
mysql_query("INSERT INTO `users` (`name`, `surname`, `username`, `mail`, `password`) VALUES ('".$name."', '".$surname."', '".$login."', '".$mail."', '".md5($password)."')");
header ('Location: login.html');
exit();
}
?>
