<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
    
	<title>Регистрация | Клуб Профессионалов</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">КП</h1>




<?php
include_once 'handler.php'; // проверяем авторизирован ли пользователь

// если да, перенаправляем его на главную страницу
if($user) {
header ('Location: index.php');
exit();
}

if (!empty($_POST['login']) AND !empty($_POST['password']) AND !empty($_POST['mail']) AND !empty($_POST['name']) AND !empty($_POST['surname']))
{
// фильтрируем логин и пароль
$login = mysql_real_escape_string(htmlspecialchars($_POST['login']));
$password = mysql_real_escape_string(htmlspecialchars($_POST['password']));
$mail = mysql_real_escape_string(htmlspecialchars($_POST['mail']));
$p = mysql_real_escape_string(htmlspecialchars($_POST['p']));
$name = mysql_real_escape_string(htmlspecialchars($_POST['name']));
$surname = mysql_real_escape_string(htmlspecialchars($_POST['surname']));


// проверяем есть ли логин в нашей базе данных
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE (`username` = '".$login."') or (`mail` = '".$mail."');"), 0) != 0)
{
header ('Location: register.html');
exit();
}

// заносим данные в таблицу, обратите внимание - пароль кодируем в md5
mysql_query("INSERT INTO `users` (`p`, `name`, `surname`, `username`, `mail`, `password`) VALUES ('".$p."', '".$name."', '".$surname."', '".$login."', '".$mail."', '".md5($password)."')");

header ('Location: lk.php');

exit();
}
?>

                <?php
$p = $_GET['p'];

echo '
            </div>
            <h3>Регистрация</h3>
            <p>Для получения доступа к сервисам - необходимо зарегистрироваться.</p>
            				
			<form class="m-t" action="register_p.php" method="post">
                <div class="form-group">
                    <input name="name" type="text" class="form-control" placeholder="Имя" required="">
                </div>
                <div class="form-group">
                    <input name="surname" type="text" class="form-control" placeholder="Фамилия" required="">
                </div>
                <div class="form-group">
                    <input name="login" type="text" class="form-control" placeholder="Логин" required="">
                </div>
                <div class="form-group">
                    <input name="mail" type="email" class="form-control" placeholder="E-mail" required="">
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control" placeholder="Пароль" required="">
                </div>
                <input name="p" type="hidden" value="'.$p.'" /><br/>

                <div class="form-group">
                        <div class="checkbox i-checks"><label> <input type="checkbox"><i></i> С правилами сервиса согласен</label></div>
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">Регистрация</button>

                <p class="text-muted text-center"><small>У Вас уже есть аккаунт?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="login.html">Вход</a>
            </form>
                ';
                ?>
            <p class="m-t"> <small>Все права защищены &copy; 2016</small> </p>
        </div>
    </div>

    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/iCheck/icheck.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
    </script>
	<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '7VymgCnRUS';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
</body>

</html>
