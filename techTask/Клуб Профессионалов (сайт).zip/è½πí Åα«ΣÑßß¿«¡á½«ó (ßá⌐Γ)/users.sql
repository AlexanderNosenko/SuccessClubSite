-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Хост: localhost:3306
-- Время создания: Июн 18 2016 г., 16:57
-- Версия сервера: 5.5.50-cll
-- Версия PHP: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `improfcl_improf`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `p` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1094 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `name`, `surname`, `username`, `password`, `mail`, `p`) VALUES
(11, 'Денис', 'Остер', 'Denis', '1f6c6908cc15eda975e896de69251305', NULL, 0),
(0, 'Admin', 'Admin', 'admin', '1f6c6908cc15eda975e896de69251305', NULL, 0),
(1031, 'Денис', 'Остер', 'TestDenis', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'test@test.ru', 3),
(1, 'Виталий', 'Немеренко', 'improfclub', 'f4ef26ed8dc7d65882a915a0d5ed46cb', 'club.mlm30@gmail.com', 0),
(28, 'Пётр', 'Короленко', 'AIhimik', '110e8b372189c043e2340c2ea7360c55', 'alhimikpay@gmail.com', 1),
(50, 'Ольга', 'Кривых', 'okryvykh', '593528d3ab7a80b9a0894125bbd54624', 'okryvykh@yandex.by', 1),
(1009, 'Алексей', 'Корнюшкин', 'Алексей', 'c121906d0e1b920005ffe02bf6a77d9f', 'alexeykornyshkin@gmail.com', 1),
(1010, 'Анатолий', '', 'Anatoly', 'ceb66c9bcff78553c48d80963604ab67', 'teleskop2013@gmail.com', 1),
(14, 'Кирилл', 'Рафиков', 'Кирилл', 'f61010cc0c2308f1b754dab8194a0500', 'maddog289@gmail.com', 1),
(70, 'Ольга', 'Шарафан', 'Olga', '50ade22fe069c0751774872979292da1', 'olginya911@gmail.com', 1),
(1013, 'Александр', '', 'александр', '50634c97a49ffdbc54798699a29903a9', 'muuustag@mail.ru', 1),
(1014, 'Татьяна', 'Петрова', 'Татьяна Петрова', 'eb2213ba83224999ab4eb28c6e0bb9f6', 'petta0303@gmail.com', 1),
(15, 'Александр', 'Александров', 'Alex1', '4a622061f477e5fe4fedceaba5154c36', 'aleksandrov.aleks.56@gmail.com', 1),
(1020, 'Татьяна', '', 'Татьяна', '916152b5f866b5f7e0370df1e4701d01', 'tatyana1408@gmail.com', 1),
(1021, 'Олег', 'Некрасов', 'Олег', '779e2a913ac7a5cd6949186115a71a24', 'oribisnes@bk.ru', 1),
(1033, 'Рита', '', 'rita26', 'd2aeac1fd276cd56a492d2e4c5887d51', 'ritab2609@gmail.com', 1),
(1034, 'Александр', '', 'Aleksandr', 'c831bea0a162b862249296429f7a2f1a', 'Bajker19@gmail.com', 1),
(1032, 'Яна', 'Бабенко', 'Yana2611', '8d3cd7526b4da3a45c6bae4f73af9d1a', 'YanaBabenko26111986@gmail.com', 1),
(1035, 'Ирина', 'Коваленко', 'melodika ', '074fd28eff0f5adea071694061739e55', 'melodika3@gmail.com', 1),
(1036, 'Максим', 'Зайцев', 'maksim0875', '2fa1e852da8c7446045abd4a80c01e40', 'mts9183669957@gmail.com', 1),
(1039, 'Анатолий', 'Марков', 'fantom', '8716e2afe87b1a1d27a4c41128f50809', 'franklinbot652@gmail.com', 1),
(1040, 'Татьяна', 'Журавская', 'tatu2016', '46645aebb240c9bac83988fb96833cf1', 'tatsiana20000@mail.ru', 1),
(1041, 'Алена', 'Камертончик', 'kamertonchik', 'bd51abeb9c420142cc9ce4841484576f', 'Kamertonchik2013@gmail.com', 1),
(1042, 'Алексей', 'Корнюшкин', 'Warriseff', 'c121906d0e1b920005ffe02bf6a77d9f', 'lehsa201197@mail.ru', 1),
(1043, 'Марина', 'П', 'MARINA', 'e08d99627c41a752e24dc4cbda8239d9', 'pradunmurka007@gmail.com', 1),
(1044, 'Юрий', 'Буховец', 'Юрий Буховец', '71dfac5f6f14d78b47b4b1f35d88c5a3', 'info@helpcomp.by', 28),
(1045, 'Татьяна', 'Юрченко', 'Tanya07', '2564734ce5980e4e1c78f349944c4378', 'otklik7@yandex.ru', 1),
(1046, 'Лариса', 'Головина', 'larisa', '015e20bdd093034e97363ef1439a72dc', 'larisagolovina@rambler.ru', 1),
(19, 'Александр', 'Алфёров', 'moybiz', '69463727ed8d222765b6442da8c3e2c5', 'moybiznes33@gmail.com', 0),
(1048, 'Наталья', 'Иванова', 'nata', 'a393eb30d169c2c3ed75151d4b537df9', 'ivanova80str@gmail.com', 1),
(1049, ' Галина ', 'Андрущенко', 'andri', '43d4ae394c6febb504a4d5e70e5fbf20', 'galekspert8@gmail.com', 1),
(1051, 'Галина', 'Стецик', 'stecik15', '45f573c706cccbdfa60459b7c932e1dc', 'stecik15@yandex.ru', 1),
(1052, 'Miroslava', 'Tsvyakh', 'RichMir', '7457ef57401972a1f6b8365052843775', 'ternomira@gmail.com', 1),
(10, 'Денис', 'Болтнев', 'mechta sbyivaetsya', '7359a6c6b9da22ac1c82afc7d8c9341a', 'cemvmec@gmail.com', 1),
(1055, 'Маргарита', 'Мантурова', 'Margarita2016', '238bec926425319638e3d9b9977e115c', 'rita8227@gmail.com', 1),
(1057, 'Венера', 'Бабий', 'venera1986', '81d2f7e0f90eb5d4c5d98dec1ee9eb01', 'VENYA.TIGRU@MAIL.RU', 1),
(1058, 'Аскар', 'Баев', 'magistr', '44b10f21fc804dc3bc813f05a56c2788', 'askaronekg@gmail.com', 1),
(1059, 'Марина', 'Иванова', 'Alialiso', '19b55cdca740fc1aad5acf4d10627dbb', 'alialiso@yandex.ru', 1),
(1060, 'Александр', 'Алексеев', 'alalp1952', '3c680b0b5691eeca0f5e9852c8a88a6b', 'ap.alexeev@yandex.ru', 1),
(1062, 'Екатерина', 'Патева', 'Екатерина Патева', 'c137d1b6bfecafca055581898bc193fc', 'pateva.katerina@yandex.ru', 1),
(1061, 'Dianikiya', 'Kolk', 'Dianikiya', 'ec0a8ac6dbc717f1cb13313aa2ad2df0', 'dianikia2014@gmail.com', 1),
(1063, 'Елена', 'Зозуля', 'angel', '11915f97fb27ea2de69b68a03c11761c', 'komlik1965@gmail.com', 1),
(1064, 'Анастасия', 'Навныко', 'faberlicstart', '4d8b5dbaf92a9a381b0edd7428820c4a', 'anick988@gmail.com', 1),
(1065, 'Lidiya', 'Repetska', 'Golden46', 'aa05dc006a197d9655b980e066838697', 'repetska@gmail.com', 1),
(1066, 'Ludmila', 'Li', 'fortuna835', 'ec5d1cfefac8cb616a8d4a377dd3c3a9', 'fortuna835@gmail.com', 1),
(1067, 'Вячеслав', 'Миля', 'vyacheslavmilya', '88dcc860a093dd6de137b1e9117e7825', 'vyacheslavmilya@gmail.com', 1),
(1068, 'Ольга', 'Зеленкова', 'cuper163', 'b8effd30242e1a328677941e55e366ae', 'fafurinao631@gmail.com', 1),
(1070, 'Татьяна', 'Мелешкина', 'varvara', 'fcea920f7412b5da7be0cf42b8c93759', 'volnamtg@gmail.com', 1),
(1080, 'Ольга', 'Фролова', 'OLGAFROL25', 'b137e12e1f726be41c066c6865763fbc', 'frolova-84@bk.ru', 1),
(1071, 'Виктор', 'Кузнецов', 'Richboy', 'f665f4bcbed593a28aecdd554130b005', 'victorkuznetsov1985@gmail.com', 1),
(1072, 'лариса', 'антонюк', 'larisa55', 'f898009c8f9e322d130ee256c0f3ba41', 'buzhak.larisa@mail.ru', 1),
(1074, 'Антон', 'Пронька', 'slovyanin42', 'aab6c60015678ee95a698a6f0cd8ddd8', '2antoxa1@gmail.com', 1),
(3, 'Сергей', 'Ронжин', 'profitlifecom', 'df605c72d1dcc1cb55bb9c7890292d75', 'evpserg@gmail.com', 2),
(2, 'Артём', 'Бобров', 'PROFIT_TEAM', '0dabe3de7a8ce486fc168dd036cc2e5a', 'artemteamprofit@gmail.com', 1),
(1089, 'Вячеслав', 'Дмитриев', 'sablikkk', 'dd39200f23b9eb55cf7e1f107846a6a2', 'sablikkk@yandex.ru', 1),
(1088, 'Ljuba', 'Boepple', 'lubiza', 'ebf71258be82c65248f733d1d38607ea', 'ljubascha.boepple@gmail.com', 1),
(1087, 'Людмила', 'Бахмат', 'bizneslife', '8608ef1ec071f84b10aeb34e039d48ca', 'ludmilamika@gmail.com', 1035),
(4, 'Клуб', 'Профессионалов', 'improf', '4ee2f529de52db387053235ad44e8713', NULL, 3),
(1090, 'Петр', 'Симанович', 'Belarus ', '8f8555f2a342f17f74b48a8c31ed9980', '9361450@gmail.com', 1),
(1091, 'Александра', 'Волчкова', 'sandra81', 'e5f19416b13af01a8734436b8fae3766', 'alexandra.volchkova@yandex.ru', 1087),
(1092, 'nasok1231', 'konikov', 'nasok1231', 'c597da2dd0c1bbdc4112e54c00a7b864', 'brat-a10@mail.ru', 1087),
(1093, 'Александр', 'Николаевич', 'aleks', '2493f29e514cf1649a0cafabd93a5daa', 'wwfftg@gmail.com', 1035);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
